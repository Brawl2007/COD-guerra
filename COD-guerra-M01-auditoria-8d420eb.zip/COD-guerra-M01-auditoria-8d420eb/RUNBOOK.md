# Executar e validar

## Onze tarefas parciais aceites — 2026-10-16

O lote `M01-PARTIALS-COMPLETION-INTEGRATION-V1` fecha T02/T03/T05/T06/T07/T14/T24/T26/T34/T36/T41. Fonte aceite `e377a0739906507dee63cd4006a3428efd22c56b`, branch `codex/m01-partials-browser-sampling-repair-v1`; produção idêntica à certificada `9a679c50`. Verificador independente PASS e revisão crítica ACCEPT; provas, limites e histórico no `docs/verification/m01-runtime/partials-completion-integration-v1/HANDOFF.md`. Node874/874, tooling173, build,24rotas causais,24futuros ON/OFF,299ficheiros protegidos, controlos integrais das pontes0 e44regressões acopladas passaram. A captura Stuka foi corrigida e validada separadamente; os runs anteriores42/44 e13/14 continuam FAIL, sem alegar uma execução integral44/44. O handoff contém a execução final e os resultados exatos da correção.

**37 tarefas principais confirmadas;15 por fechar**, incluindo T53. T21/PR65 e T50/PR66 são candidatos existentes fora deste lote. M01 continua PROTÓTIPO JOGÁVEL; playtest humano e performance no PC-alvo pendentes. As variâncias T24-CAMERA-01 e T36-EXPOSURE-01 e os FAIL históricos permanecem explícitos; main não é modificada.

O conteúdo abaixo é histórico e conserva o estado da respetiva data.

Node >=22.12.0; CI em Node 24. Dependências fixadas: Three.js 0.186.1, Vite 8.3.1, Playwright 1.58.2. `package-lock.json` versionado.

```sh
npm ci
npm test
npm run build
npm run dev
```

Dev: `http://127.0.0.1:5173/COD-guerra/`. `npm start` é um alias para dev. Produção: `npm run preview`, `http://127.0.0.1:4173/COD-guerra/`.

```sh
npx playwright install --with-deps chromium
npm run test:browser
```

A suíte de navegador inicia o preview do build automaticamente e verifica o prefixo de Pages. Sempre executar build após editar. Capturas e traces são gravados em `test-results/` e enviados como `browser-evidence` no CI. No ambiente desta sessão, o download CFT falhou; usou-se Chromium 153 extraído de um pacote npm em scratch:

```sh
CHROME_EXECUTABLE=/caminho/para/chromium npm run test:browser
```

Essa variável é opcional e não afecta produção/CI. O renderer de teste usa SwiftShader; os resultados não medem desempenho do Chromebook. `agent-browser` foi tentado e seu daemon não arrancou neste ambiente; a verificação efectiva foi realizada com Playwright e imagens inspeccionadas.

O CI mantém viewport 1280×720 e as mesmas assertions, com 180 s por teste (120 s para o percurso) por causa da renderização em software no runner. Não há retries automáticos. Traces, capturas e diagnóstico de simulação nas falhas ajudam a distinguir espera lenta de erro de jogo.

Suíte completa (`.github/workflows/pages.yml`, job `browser`, 4 shards): usar `npm run build:browser` em vez de `npm run build` antes de `npm run test:browser`. Faz primeiro o build de produção (idêntico a `npm run build`) e acrescenta ao mesmo `dist` os visualizadores de autoria abertos por specs (`m01-material-atlas`, `m01-bridge-material-kit`, `m01-vegetation-kit`); `dist` publicado continua só com o jogo. `m01-postprocess-grading.spec.js` (T44) exige `M01_GRADING_BEFORE_DIR` com os frames BEFORE da mesma árvore sem o passe de grading: `tools/verification/m01-grading-before.sh <shard> 4 <dir>` cria um worktree de HEAD, retira o grading (`m01-grading-strip.mjs`), compila e corre o spec em modo `M01_GRADING_BASELINE=1`; só trabalha no shard que contém o spec. Localmente, com HEAD já commitado: `M01_GRADING_BEFORE_DIR=$PWD/.agent/runs/grading-before/png tools/verification/m01-grading-before.sh 1 1 "$M01_GRADING_BEFORE_DIR"` e depois o spec com a mesma variável.

## Controlos e estado

WASD: mover; mouse: olhar; clique esquerdo: um disparo semiautomático; botão direito: mira; R: recarregar; G: granada; Shift: correr; Esc: libertar rato/pausar. Iniciar/Retomar solicita pointer lock e habilita áudio por gesto. Perder foco limpa as teclas e pausa simulação/áudio.

O selector inicia M01 por defeito. A bancada francesa continua seleccionável; `?mission=sandbox-1944` abre-a directamente. M01: E entrega mensagem/material e leva/entrega Bąk; C agacha; V alterna alça 300/500/800/1000 m; Espaço salta somente intro/outro. A referência da alça não implementa queda balística. O wz.29 tem 5 + 40 cartuchos, 2 granadas, ferrolho e recarga por clipe quando vazio; cargas parciais inserem um cartucho de cada vez.

Rota inicial de M01: contorne a trincheira pelo lado sul, atravesse a passagem aberta do portal ferroviário e use E junto de Nowicki. Depois do ataque siga Zieliński até à reorganização, encontre Krawiec no aterro e entre no barracão pela porta oeste para recolher material. Regresse aos sapadores, mantenha o acesso rodoviário, cubra o pelotão e recue ao posto de disparo/abrigo quando receber ordem.

Ao capturar o rato, o input espera a confirmação de pointer lock e descarta a primeira amostra relativa para evitar o salto de coordenadas do cursor. Os movimentos seguintes controlam yaw/pitch normalmente, incluindo após retomar.

Na bancada, checkpoint automático ao atingir C e chave `cod-guerra:checkpoint:v1`. Em M01, CP-A..D usam `cod-guerra:checkpoint:m01:v2`, com os dois relógios, estado real da arma, actores, eventos, flags, diálogos, sectores e destruição. CP-C é adiado até 05:34; CP-D usa posição/hora actuais. Reiniciar Checkpoint restaura o snapshot vivo; Continuar restaura após reload da página. Saves inválidos mostram erro e deixam iniciar de novo. Versões desconhecidas são rejeitadas.

As pontes usam nove GLB de apresentação e colisores em JSON. Se um dos nove GLB obrigatórios das pontes falhar, o menu mostra erro e bloqueia início/continuação para não criar uma ponte invisível; a bancada francesa mantém o fallback próprio. Os GLB opcionais de soldados e aviões mantêm os proxies quando faltam. `gameDiagnostics().m01.requiredAssetFailures` distingue as pontes de `assetFailures`, que também regista o Ju 87. `m01.aircraft` mostra LODs carregados, nível seleccionado, posição, atitude (`attitude`, só rotação de apresentação), `fade` e hélice dos três aviões; hélice, atitude e fade usam o relógio da missão e conservam a pausa/restauro. `m01.wagons` mostra 65 vagões, passo 9,10 m, LOD2, tipos carregados e contagem de proxies. `m01.characters.actors` identifica `de_east_0/1` com MG34, `weaponLOD`, boca real e clip; `characters.failures` regista as falhas opcionais da arma/clips. As duas fontes ficam dentro do limite 18/24/28. A postura deitada e a dupla aguardam dados de simulação. Para verificar a exportação e repetir o percurso de simulação:

```sh
npm run assets:m01:colliders -- --check
node tools/verify-m01-route.mjs
node --test tests/m01-runtime.test.js
```

Partida contínua de M01 no navegador, do menu ao debrief, numa única sessão (≈19 min reais em SwiftShader):

```sh
npm run build && npm run preview &
CHROME_EXECUTABLE=/caminho/para/chromium node tools/m01-browser-playthrough.mjs --out test-results/m01-continuous
```

O piloto usa teclado/cliques reais e olhar por `mousemove` relativo, e só lê `gameDiagnostics()` e o HUD: não injecta snapshots, relógios, eventos ou objectivos. Regista bloqueios de movimento, esperas, legendas, mensagens e uma captura por objectivo em `report.json`/`log.jsonl`. É um piloto automático; não substitui um playtest humano. `--skip-cutscenes` salta intro/outro com Espaço. `--adverse` acrescenta rotas adversas:
- sair dos limites a leste e cair no Vístula, cada uma com restauro de CP-A;
- ficar 2 min parado sem seguir o sargento;
- gastar a munição e pedir carregadores a Kowal.

`--cover help|ignore` compara as duas maneiras de jogar "Proteja o reparo" e "Cubra a retirada":
- `help`: o piloto fica na encosta ao lado dos sapadores e cala a MG dos portões, mirando o último clarão visto (`threat.recentFire`). Depois pede carregadores a Kowal e, do lado sul do tabuleiro, dispara sobre os alemães do tabuleiro.
- `ignore`: o piloto espera abrigado sem disparar.

O relatório guarda em `cover`:
- duração do reparo, supressões e percentagem de tempo com a MG calada;
- baixas do pelotão e sobreviventes;
- tiros dados;
- as linhas de estado do HUD e cada vez que divergem da simulação.

Comparação de estado (simulação, sem navegador), por sementes:

```sh
node tools/m01-cover-comparison.mjs [--seeds 19390901,1,2] [--out caminho.json]
```

Os modelos provisórios das pontes regeneram-se com `cd tools/assets/m01-bridges && npm ci && npm run build`; a exportação é determinística. Depois correr `npm run assets:m01:colliders -- --check` e `npm test`.

O verificador grava `docs/verification/m01-runtime/simulation-report.json`. Usa controlos e física reais da simulação com passos de 50 ms, sem injectar relógios/eventos/objectivos. Não é playtest no navegador. Testes de CP-D/outro no navegador continuam snapshots alcançados por esse percurso; estão identificados como verificações por trechos.

Verificação isolada das poses (porta 5181, servidor/browser fechados ao terminar):

```sh
CHROME_EXECUTABLE=/caminho/para/chromium node tools/verify-m01-poses.mjs --out test-results/m01-poses
```

A galeria usa o renderer de personagens com dados de exemplo; não executa a missão. O teste de navegador da chamada usa um snapshot alcançado pela rota de simulação e verifica a pose após reload.

Para a galeria de combate (mira, recuo, postura sob fogo e passo), com dois instantes do mesmo relógio de apresentação:

```sh
CHROME_EXECUTABLE=/caminho/para/chromium node tools/verify-m01-poses.mjs --combat --out test-results/m01-combat-poses
```

Os controlos de relógio desta galeria existem apenas na fixture de verificação. `gameDiagnostics().m01.actorAnimations` mostra as contagens renderizadas de mira, disparo, movimento e supressão; não é estado de gameplay. Provas e limites em `docs/verification/m01-runtime/combat-animation/`.

Galeria de danos ambientais (marcas por material, crateras, queimados e resíduo das demolições), com o renderer real e uma `M01Simulation` descartável servidos pelo `vite` de desenvolvimento; impactos vêm de `traceShot`/`traceRound` e explosões de `consume()` reais:

```sh
CHROME_EXECUTABLE=/caminho/para/chromium node tools/verification/m01-damage-decals-gallery.mjs test-results/m01-damage-decals [brick-portal,railway,...]
```

`gameDiagnostics().m01.damageDecals` mostra marcas, resíduo, detritos, brasas e contadores; é apresentação, não entra no save. Provas e limites em `docs/verification/m01-runtime/environmental-damage-decal-pass-v1/`.

Comparação do combate de cobertura, duas rotas completas da simulação com a mesma seed:

```sh
node tools/verify-m01-cover.mjs
```

O piloto move-se, aponta com deltas de input e usa disparo/ferrolho/recarga. Não altera actores, RNG, eventos ou relógios; não é uma partida no navegador. Gera `docs/verification/m01-runtime/cover-combat/report.json`, com tiros a menos de 3 m (`round-impact.pinned`) e baixas por tiro real (`victim`). O navegador verifica por continuação o HUD, os efeitos e a pose dos sapadores no reparo, e as perdas na retirada. A flecha do tiro alemão é aproximação de jogo; a balística continua pendente.

## Diagnóstico

O clip opcional `m01_station_animations.glb` é gerado com `node tools/assets/m01-station/build.mjs`, sobre o rig fixado no seu manifesto. `gameDiagnostics().m01.stationEvacuation` resume dados reais do ferido e de Dudek. A primeira pessoa exige os clips de arma/transporte: o clip da estação, sozinho, não a activa. Kowal/Bąk e os sockets das suas armas aparecem em `m01.characters.actors`; isso é apresentação, não autoridade de combate.

Os soldados e as mãos de M01 carregam GLB com texturas incorporadas sob o mesmo prefixo de produção. Todas as qualidades carregam LOD0/1/2 polacos, LOD2 alemão e o ficheiro de clips. O LOD0 fornece a arma e os braços em primeira pessoa; a qualidade baixa usa LOD1/2 no cenário e limita os soldados com skinning a 18. Se o LOD0 faltar, as mãos usam o LOD1; falhar todos os modelos conserva a apresentação procedural. Não muda o estado do actor nem bloqueia a missão; uma ponte em falta continua a bloquear o início.

Galeria dos seis LODs e quinze clips, em Chromium, com relatório e capturas:

```sh
CHROME_EXECUTABLE=/caminho/para/chromium node tools/verify-m01-characters.mjs test-results/m01-characters
```

É revisão isolada de assets. As capturas de produção por trechos e as verificações de ferrolho/clipe/cartucho usam o jogo construído. `gameDiagnostics().m01.characters` e `.viewModel` expõem apenas dados de apresentação; não são guardados no save. Créditos, limitações e provas em `docs/verification/m01-runtime/characters/README.md`.

`?debug=1` habilita somente `window.gameDiagnostics()`: renderer, preset, chamadas/triângulos, assets, relógio, posição, fase e sectores. Não expõe a instância nem permite mutações. Não deixar informação de engenharia no HUD normal.

Se o ecrã falha, inspeccionar consola, rede e `#error`. Ausência de WebGL2 mostra mensagem. Asset ausente aparece no diagnóstico e utiliza fallback, sem aprovar qualidade final. `base` deve continuar `/COD-guerra/`; Vite copia `assets` para `dist/assets` no build.

## Publicação

Há um único workflow `.github/workflows/pages.yml`. PRs executam validação; pushes para main/master ou workflow_dispatch validam e publicam somente dist. Deploy depende da validação e tem concorrência Pages própria. Esta alteração deve chegar por PR para main; não publicar directamente uma bancada como campanha concluída.

## HUD e apresentação de M01

`src/ui/m01-hud.js` apresenta objectivos, avisos, cartelas, fades, interacção, munição e saúde a partir do estado da simulação; não escreve nela. Os tempos usam o relógio da simulação (congelam na pausa). `gameDiagnostics().m01.hudPresentation` mostra aviso actual, fila, fade e cartelas (só apresentação). Capturas em seis resoluções, por snapshots da rota real e pausa real:

```sh
npm run build
CHROME_EXECUTABLE=/caminho/chromium node tools/verification/m01-hud-capture.mjs test-results/m01-hud after
```

`HUD_VIEWPORTS=1280x720,800x600` e `HUD_SCENES=intro-card-place,cp-a-objective` restringem a execução. O relatório regista elementos fora do ecrã e sobreposições entre blocos do HUD. Não é playtest humano nem medição de FPS.

## Verificação visual de M01

Para verificar a origem da salva nos portões e atrás da treliça, depois do build:

```sh
CHROME_EXECUTABLE=/caminho/chromium node tools/capture-m01-visual.mjs test-results/m01-cover-origin --cover-origin-only
```

São continuações de snapshots alcançados por controlos da simulação, esperando em cobertura até uma salva real. O script fecha preview/browser; não é uma partida humana ou contínua.

Para capturar somente a demolição leste, por continuação de snapshots alcançados pela rota de simulação, dentro e fora da treliça:

```sh
npm run build
CHROME_EXECUTABLE=/caminho/chromium node tools/capture-m01-visual.mjs test-results/m01-demolition --demolition-only
```

O script inicia e fecha o seu preview/browser. Guarda capturas originais e erros/diagnóstico; não é partida contínua nem playtest humano. Os snapshots exteriores usam movimento real na simulação até x < −100 depois da demolição.

```sh
npm run build
CHROME_EXECUTABLE=/caminho/chromium node tools/capture-m01-visual.mjs docs/verification/m01-runtime/visual-sprint/after
```

O script gere o seu preview, importa a rota do directório corrente e continua snapshots genuínos no browser; não é playtest contínuo/humano. Captura reparo, estação, retirada e chamada, com diagnóstico e erros. Antes de comparar, usar a mesma qualidade/viewport. Não executar com outro servidor na porta 4173. Guardar capturas fora de `test-results/` se precisarem sobreviver ao próximo Playwright, que limpa essa pasta.

## Auditoria de continuação schema 2

```sh
mkdir -p test-results
M01_DETERMINISM_REPORT=test-results/m01-schema2-audit.json node --test tests/m01-schema2-determinism.test.js
```

Compara duas continuações com os mesmos inputs/dt a cada tick e indica o primeiro caminho/tick divergente. Inclui rotas completas, CP-A..D, morte/recuperação, MG34 mid-burst, granadas, estação/Bąk, demolições, casualties, OUTRO e migrações legacy. É teste Node, não playtest humano nem benchmark de FPS.

`M01Simulation.snapshot()` cria um save de continuação com `resumeCheckpoint` opcional plano para preservar o CP anterior. `snapshot(false)` cria um snapshot plano para instalar explicitamente um novo checkpoint ou fabricar uma fixture legacy. Os CP-A..D e a persistência normal do jogo continuam planos em schema 2. Saves antigos sem o novo campo conservam o contrato anterior. Não guardar cadeias de backups; o validador rejeita aninhamento, backups futuros e campos de arma que não pertencem ao snapshot real.

Evidências/reprodução/limites: `docs/verification/m01-runtime/schema2-determinism-audit-2026-10-03/HANDOFF.md`.

## Guarda do bundle inicial (T50)

Depois de `npm run build`, `npm run verify:bundle` (`tools/verify-t50-bundle.mjs`) escreve `artifacts/t50-proof/t50-bundle-metrics.json` e falha se o chunk de entrada `index-*.js` tiver >= 600 000 bytes. `tests/m01-t50-font-footer-bundle.test.js` garante sem build que o grafo estático de `src/main.js` não importa `three` nem `src/game|render|sim` (carregados por `import()`), e verifica a fonte Barlow self-hosted, o `@font-face`/preload e o rodapé ligado ao estado.
