# COD-guerra M01 — Auditoria completa

Auditoria: `8d420eb3dcb51c3b05c0213856f3eb1266e43cd7`. Jogo avaliado: PR #80, `68301b779b856af46ed35a10fde42df9559d9ed4`.

[Identificação e conteúdo do ZIP](LEIA-ME.txt) · [Índice completo da auditoria](docs/verification/m01-quality-inspector/README.md)

## Documentos

- [A — Playtest integral](docs/verification/m01-quality-inspector/A-PLAYTEST-INTEGRAL.md)
- [B — Crítica profissional](docs/verification/m01-quality-inspector/B-CRITICA-PROFISSIONAL.md)
- [C — Referências e limitações](docs/verification/m01-quality-inspector/C-COMPARACAO-REFERENCIAS.md)
- [D — História e roteiro Fable](docs/verification/m01-quality-inspector/D-HISTORIA-E-ROTEIRO.md)
- [E — Audiovisual](docs/verification/m01-quality-inspector/E-AUDIOVISUAL.md)
- [F — Correções priorizadas](docs/verification/m01-quality-inspector/F-CORRECOES-PRIORIZADAS.md)
- [G — Plano de qualidade](docs/verification/m01-quality-inspector/G-PLANO-DE-QUALIDADE.md)
- [15 respostas ao proprietário](docs/verification/m01-quality-inspector/CONCLUSOES.md)
- [Scorecard](docs/verification/m01-quality-inspector/SCORECARD.md)
- [Verificações e resultados de testes](docs/verification/m01-quality-inspector/VERIFICACOES.md)
- [Catálogo original das capturas](docs/verification/m01-quality-inspector/CAPTURAS.md)

## Evidências e referências

- [Screenshots do percurso](docs/verification/m01-quality-inspector/evidence/route/)
- [Capturas High independentes](docs/verification/m01-quality-inspector/evidence/navigation-high/)
- [Resultados de testes e logs](docs/verification/m01-quality-inspector/evidence/checks/)
- [Referências Fable originais](docs/creative-direction/README.md)
- [Registo do acesso às referências externas](docs/verification/m01-quality-inspector/evidence/reference-access.json)
- [Manifesto do ZIP](MANIFESTO-ZIP.json)

As fontes externas bloqueadas continuam identificadas como não verificadas. Não foram incluídos vídeos.
