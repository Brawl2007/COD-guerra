# Page snapshot

```yaml
- main [ref=e2]:
  - generic "Jogo de tiro em primeira pessoa" [active] [ref=e3]
  - generic:
    - generic:
      - generic: OBJETIVO ACTUAL
      - strong: Leve a mensagem e o café ao posto da ponte
    - time: 04:31:13
    - generic:
      - generic:
        - generic: SAÚDE
        - text: "100"
        - generic: GRANADAS ×2
      - generic:
        - generic: KARABINEK WZ.29
        - text: "5"
        - emphasis: /
        - text: "40"
        - generic: 300 m · 5 CARTUCHOS
    - generic: CHECKPOINT ALCANÇADO
```